#include <stdio.h>

int main()
{
    /*Thi is a comment*/

    int a = 0;
    int b = 5; 

    //This is a comment

    for(a = 0; a < 5; a++)
    {
        /*Thi is another comment*/
        printf("%d\n", b);
        b++;
    }
    //another comment

    return 0;
}